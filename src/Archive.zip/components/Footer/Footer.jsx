import React from 'react'
import './Footer.css'

const Footer = () => {
  return (
    <div className='footer'>
        <p>2026 AutoFix Transmissions L.L.C. All Rights Reserved.</p>
        <ul>
            <li>Terms of Service</li>
            <li>Privacy Policy</li>

        </ul>
      
    </div>
  )
}

export default Footer
